# Si o que
# Que si que
# Ah sii?
# Que sii
# Sii? Pos vale
# Ah pos vale
# Pos si o que
# Que si que
# Pos si
# Que si??
# Que si que
